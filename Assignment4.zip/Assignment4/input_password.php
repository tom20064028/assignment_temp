<html>
<head>
	<meta charset="UTF-8">
</head>
<body>
	<?php
	if(!isset($_COOKIE["username"]) && !isset($_COOKIE["password"]))
	{
		?>
		<form method="get" action="checkpassword.php">
			<table border="0">
				<tr><td>User ID</td><td><input type="text" name="usercode"></td></tr>
				<tr><td>Password</td><td><input type="password" name="userpassword"></td></tr>
				<tr><td><input type="Submit" value="Login"></td></tr>
			</table>
		</form>
		<?php
	}else
	{
		echo "You have login as someuser";
		?>
		<form method="get" action="logout.php">
			<table border="0">
				<tr><td><input type="Submit" value="Logout"></td></tr>
			</table>
		</form>
		<?php
	}
	?>
</body>
</html>
