<?php
$dbhost = "localhost" ;
$dbusername = "root";
$dbpassword = "root";
$dbname = "workshop";

$dbh = MYSQLi_CONNECT($dbhost,$dbusername,$dbpassword) OR DIE ("Bye Bye");
mysqli_select_db($dbh,"$dbname") OR DIE ("Bye bye bye");

if (isset($_FILES['image']) && $_FILES['image']['size'] > 0) { 

// Temporary file name stored on the server
    $tmpName  = $_FILES['image']['tmp_name'];  

// Read the file 
    $fp      = fopen($tmpName, 'r');
    $data = fread($fp, filesize($tmpName));
    $data = addslashes($data);
    fclose($fp);


// Create the query and insert
    mysqli_query ($dbh,"insert into filearchive values ( \"$tmpName \", \"$data\" )")
    || die ("Cannot insert file into archive.<br>\n");
    print ("$filename check-in filearchive okay.<br>\n");


// Print results
    print "Thank you, your file has been uploaded.";

}
else {
    print "No image selected/uploaded";
}

?>