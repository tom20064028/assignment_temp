<?php
setcookie("username", null, time() - (3600), "/");
setcookie("password", null, time() - (3600), "/");
?>

<html>
<?php
echo "You have logged out sucessfully";
?>
<form method="get" action="input_password.php">
	<table border="0">
		<tr><td><input type="Submit" value="Back"></td></tr>
	</table>
</form>
</html>