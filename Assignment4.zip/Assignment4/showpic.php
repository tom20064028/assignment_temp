<html>
<head>
	<meta charset="UTF-8">
</head>
<body>
<?php                                                                                          
$dbhost = "localhost" ;
$dbusername = "root";
$dbpassword = "root";
$dbname = "workshop";

$dbh = MYSQLi_CONNECT($dbhost,$dbusername,$dbpassword) OR DIE ("Bye Bye");
mysqli_select_db($dbh,"$dbname") OR DIE ("Bye bye bye");
$filename = $_get['name'];
$result = mysqli_query ("SELECT myimage from filearchive
                         where myfilename = \"$filename\" ") ;
if (!$result) die ("Cannot select record from archive.<br>\n");
if ( MYSQLi_NUM_ROWS( $result ) < 1 )
 { die ("File was not check in.<br>\n") ; }
$row = MYSQLi_FETCH_ROW( $result ) ;
$image =  $row[]  ;
header('Content-type: image/jpeg');
print ( $image );
?>
</body>
</html>
