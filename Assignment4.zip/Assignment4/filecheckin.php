<html>
<head>
	<meta charset="UTF-8">
</head>
<body>
<?php
$dbhost = "localhost" ;
$dbusername = "root";
$dbpassword = "root";
$dbname = "workshop";

$dbh = MYSQLi_CONNECT($dbhost,$dbusername,$dbpassword) OR DIE ("Bye Bye");
mysqli_select_db($dbh,"$dbname") OR DIE ("Bye bye bye");
$filename = "sample2.jpg";
if ( !($file_in = fopen("$filename","rb")) )
 { die("Cannot open input file.<br>\n");
 }
$image = addslashes(fread($file_in,filesize("$filename")));
mysqli_query ($dbh,"insert into filearchive values ( \"$filename\", \"$image\" )")
 || die ("Cannot insert file into archive.<br>\n");
print ("$filename check-in filearchive okay.<br>\n");
?>
</body>
</html>
