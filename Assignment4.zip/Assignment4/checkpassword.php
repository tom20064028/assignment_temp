
<html>
<head>
	<meta charset="UTF-8">
</head>
<body>
	<?php
	$dbhost = "localhost";
	$dbusername = "root";
	$dbpassword = "root";
	$dbname = "workshop";
	$correct = false;

	$dbh = MYSQLi_CONNECT($dbhost,$dbusername,$dbpassword) OR DIE ("Bye Bye");
	mysqli_select_db($dbh,"$dbname") OR DIE ("Bye bye bye");

	$usercode = $_GET["usercode"];
	$userpassword = $_GET["userpassword"];

	$query = "SELECT * FROM authentication where usercode = \"$usercode\"
	and userpassword = password('$userpassword')" ;

	$result = MYSQLi_QUERY($dbh,$query) ;

	if( $record = MYSQLi_FETCH_ROW( $result ) ){
		setcookie("username", $usercode, time() + (3600), "/");
		setcookie("password", $userpassword, time() + (3600), "/");
		$correct = true;
	}
	if($correct){
		$query = "SELECT userimagename FROM authentication where usercode = \"usercode\"";
		$result = MYSQLi_QUERY($query) ;
		$row = MYSQLi_FETCH_ROW( $result ) ;
		$imgname = $row[0];
		print "Welcome!! $usercode <br />";
		echo "<img src='showpic.php?name=$imgname' height='200' width='200' /> </br>";

	}else
		print "The username or password is wrong.<br>\n" ;

	MYSQLi_CLOSE($dbh);
	?>
</body>
</html>